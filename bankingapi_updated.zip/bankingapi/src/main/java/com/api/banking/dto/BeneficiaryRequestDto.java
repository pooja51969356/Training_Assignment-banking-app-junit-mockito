package com.api.banking.dto;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class BeneficiaryRequestDto {
	
	private  String customerId;
	@NotEmpty(message="provide beneficiary name")	
	@Pattern(regexp = "^[a-zA-Z0-9_ ]*$",message = "provide valid beneficiary name")
	private  String  beneficiaryName;
	@Digits(fraction = 0, integer = 13 ,message = "Provide Beneficiary Account No")
	@DecimalMin(value = "0.0",inclusive = false)
	private  BigInteger beneficiaryAccountNo;
	@NotEmpty(message="provide beneficiary IFS Code")
	@Size(min = 5, max = 15) 
	@Pattern(regexp = "[a-zA-Z0-9]+",message = "provide valid ifsCode")
	private  String beneficiaryIfsCode;
	private  String  beneficiaryBranchAdd;
	@Digits(fraction = 0, integer = 13 ,message = "Provide Beneficiary Max Transaction Amount Limit")
	@DecimalMin(value = "0.0",inclusive = false,message = "Provide Beneficiary Max Transaction Amount Limit")
	private  Double  maxTransactionAmountLimit;
	

}
