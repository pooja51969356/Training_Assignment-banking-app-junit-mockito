package  com.api.banking.entity;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity(name="beneficiary_details")
@IdClass(BeneficiaryIdEntity.class)
public class BeneficiaryEntity {
   

	@Id
	@Column(name="account_no")
	private BigInteger accountNo ;
	@Column(name = "ifs_code")
	private  String ifsCode ;
	@Column(name = "branch_add")
	private  String  branchAdd ;
	@Column(name = "name")
	private  String  name ;
	@Column(name = "balance")
	private  Double  balance ;
	@Column(name = "maxTransactionAmountLimit")
	private  Double  maxTransactionAmountLimit ;
	@Id
	@Column(name = "customer_id")
    private String customerId;
}
