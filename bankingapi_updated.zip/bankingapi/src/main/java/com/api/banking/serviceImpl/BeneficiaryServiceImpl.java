package  com.api.banking.serviceImpl;



import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.api.banking.dto.BeneficiaryRequestDto;
import com.api.banking.dto.BeneficiaryResponseDto;
import com.api.banking.entity.BeneficiaryEntity;
import com.api.banking.repository.BeneficiaryRepository;
import com.api.banking.repository.CustomerRespository;
import com.api.banking.service.BeneficiaryService;
import com.api.banking.exception.InavalidAccountException;


@Service
public class BeneficiaryServiceImpl implements BeneficiaryService{
	
	private static final Logger logger = LoggerFactory.getLogger(BeneficiaryServiceImpl.class);

	@Autowired
	BeneficiaryRepository dao;
	@Autowired
	CustomerRespository cdao;

	@Override
	public BeneficiaryResponseDto createBeneficiaryAccount(BeneficiaryRequestDto beneficiaryDto){
		
		//logger.info("enter block");
		
		//check customer id exist
		if(cdao.findByCustomerId(beneficiaryDto.getCustomerId())==null) {							 
			logger.info("Invalid CustomerId");
			throw new InavalidAccountException("CustomerId account not exist!!!!!!");
		}
		
		
		Optional<BeneficiaryEntity> beneficiaryEntity =dao.findByAccountNoAndCustomerId(beneficiaryDto.getBeneficiaryAccountNo(),beneficiaryDto.getCustomerId());
		
		if(!beneficiaryEntity.isEmpty()) {			
			//check beneficiary a/c no exist or not													
			logger.info("Invalid Beneficiary Detail");
			throw new InavalidAccountException("Beneficiary account nunber already exist with CustomerId :-"+beneficiaryDto.getCustomerId());
		}
		
		BeneficiaryEntity beneficiaryResponse=new BeneficiaryEntity();
		
		try {
		
			beneficiaryResponse=dao.save(prepareBeneficiaryDao(beneficiaryDto));
			
		} catch (Exception e) {
			throw new IllegalArgumentException("Beneficiary Not Added Succesfully..!! Resson: "+e.toString());
		}
		
		
		
		return prepareBeneficiaryResponseDto(beneficiaryResponse,beneficiaryDto);
		
		
		
	}
	private BeneficiaryEntity prepareBeneficiaryDao(BeneficiaryRequestDto beneficiaryRequestDto) {
		
		BeneficiaryEntity responseMas = new BeneficiaryEntity();
		
		responseMas.setAccountNo(beneficiaryRequestDto.getBeneficiaryAccountNo());
		responseMas.setIfsCode(beneficiaryRequestDto.getBeneficiaryIfsCode());
		responseMas.setName(beneficiaryRequestDto.getBeneficiaryName());
		responseMas.setBranchAdd(beneficiaryRequestDto.getBeneficiaryBranchAdd());
		responseMas.setMaxTransactionAmountLimit(beneficiaryRequestDto.getMaxTransactionAmountLimit());
		responseMas.setBalance(0.0);
		responseMas.setCustomerId(beneficiaryRequestDto.getCustomerId());
		return responseMas;
	}
	private BeneficiaryResponseDto prepareBeneficiaryResponseDto(BeneficiaryEntity responseMas,BeneficiaryRequestDto beneficiaryDto) {
		
		//validation
		
		BeneficiaryResponseDto beneficiaryResponseDto = new BeneficiaryResponseDto();
		beneficiaryResponseDto.setBeneficiaryName(responseMas.getName());
		beneficiaryResponseDto.setStatus("Beneficiary Added Succesfully...!!!");
		
		return beneficiaryResponseDto;
	}
}
