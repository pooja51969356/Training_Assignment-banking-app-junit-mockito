package  com.api.banking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import  com.api.banking.entity.TransactionEntity;

public interface FundTransferRepository extends JpaRepository<TransactionEntity, Integer>{

}
