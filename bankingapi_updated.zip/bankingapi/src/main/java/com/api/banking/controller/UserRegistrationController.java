package com.api.banking.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import  com.api.banking.dto.RegisterAccountRequestDto;
import  com.api.banking.dto.UserLoginResponseDto;

import  com.api.banking.service.UserRegistrationService;
@RestController
@Validated
public class UserRegistrationController {

	@Autowired
	UserRegistrationService createAccountService;
	
	
	
	@RequestMapping(path = "api/user/createAccount",method = RequestMethod.POST)
	public ResponseEntity<UserLoginResponseDto>createAccount(@Valid @RequestBody RegisterAccountRequestDto registerAccountRequestDto) {
		
		return ResponseEntity.ok(createAccountService.createAccount(registerAccountRequestDto));

	}
	
}
