package  com.api.banking.service;

import com.api.banking.dto.RegisterAccountRequestDto;
import com.api.banking.dto.UserLoginResponseDto;




public interface UserRegistrationService {
	
	public UserLoginResponseDto createAccount(RegisterAccountRequestDto registerAccountRequestDto);

	
}
