package  com.api.banking.service;

import com.api.banking.dto.LoginDetails;
import com.api.banking.dto.LoginResponseDto;

public interface LoginService {
	
	public LoginResponseDto customerLogin(LoginDetails login);

}
