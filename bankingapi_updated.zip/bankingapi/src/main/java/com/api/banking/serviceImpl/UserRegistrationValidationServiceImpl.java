package com.api.banking.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.api.banking.entity.CustomerEntity;
import com.api.banking.repository.CustomerRespository;
import com.api.banking.service.UserRegistrationValidationService;

@Service
public class UserRegistrationValidationServiceImpl implements UserRegistrationValidationService {
	
	@Autowired
	CustomerRespository customerRespository;


	@Override
	public boolean panAlreadyExists(String panno) {
		try {
			CustomerEntity u=customerRespository.findByPanNumber(panno);
			System.out.println(u.toString());
			return true;
		} catch (Exception e) {
		}
		return false;
	}

	@Override
	public boolean emailAlreadyExists(String email) {
		try {
			CustomerEntity u=customerRespository.findByEmailId(email);
			System.out.println(u.toString());
			return true;
		} catch (Exception e) {
		}
		return false;
	}

	@Override
	public boolean adhaarNumberAlreadyExists(String l) {
		try {
			CustomerEntity u=customerRespository.findByAdhaarNumber(l);
			System.out.println(u.toString());
			return true;
		} catch (Exception e) {
		}
		return false;
	}

}
