package com.api.banking.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Date;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Matchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.api.banking.dto.RegisterAccountRequestDto;
import com.api.banking.dto.UserLoginResponseDto;
import com.api.banking.service.UserRegistrationService;
import com.api.banking.service.UserRegistrationValidationService;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest
public class UserRegistrationValidationServiceTest {

	
	@Autowired
	UserRegistrationValidationService userRegistrationValidationService;

	
	RegisterAccountRequestDto registerAccountRequestDto;
	
	@Autowired
	UserRegistrationService userRegistrationService;
	
	@BeforeAll
	public static void insertRecordBeforeTestCase() {

		
	}
	
	
	@Test
	@DisplayName("Email Id Existence : common Scenario")
	@Order(1)
	void TestCase_1_checkEmailIdExistence_When_UserRegistration() {


		userRegistrationValidationService=mock(UserRegistrationValidationService.class);

		when(userRegistrationValidationService.emailAlreadyExists(Matchers.anyString())).thenReturn(true);
		
		
		boolean expectedResult=true;
		
		boolean result=userRegistrationValidationService.emailAlreadyExists("vksingh@gmail.com");
		
		assertEquals(expectedResult, result);
		
	}

	@Test
	@DisplayName("Pan No Existence : common Scenario")
	@Order(2)
	void TestCase_2_checkPanNoExistence_When_UserRegistration() {


		userRegistrationValidationService=mock(UserRegistrationValidationService.class);

		when(userRegistrationValidationService.panAlreadyExists(Matchers.anyString())).thenReturn(true);
		
		
		boolean expectedResult=true;
		
		boolean result=userRegistrationValidationService.panAlreadyExists("JKIUI8989J");
		
		assertEquals(expectedResult, result);
		
	}
	
	@Test
	@DisplayName("Aadhar No Existence : common Scenario")
	@Order(3)
	void TestCase_3_checkAadharNoExistence_When_UserRegistration() {


		userRegistrationValidationService=mock(UserRegistrationValidationService.class);

		when(userRegistrationValidationService.adhaarNumberAlreadyExists(Matchers.anyString())).thenReturn(true);
		
		
		boolean expectedResult=true;
		
		boolean result=userRegistrationValidationService.adhaarNumberAlreadyExists("745844125478");
		
		assertEquals(expectedResult, result);
		
	}	
	
	
	
	
	
	
}
