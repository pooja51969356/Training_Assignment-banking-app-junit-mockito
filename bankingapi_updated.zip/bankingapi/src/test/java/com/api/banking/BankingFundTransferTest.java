package com.api.banking;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigInteger;
import java.util.Date;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.function.Executable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.api.banking.controller.BeneficiaryController;
import com.api.banking.controller.FundTransferController;
import com.api.banking.controller.UserLoginController;
import com.api.banking.dto.BeneficiaryRequestDto;
import com.api.banking.dto.BeneficiaryResponseDto;
import com.api.banking.dto.FundTransferRequestDto;
import com.api.banking.dto.FundTransferResponse;
import com.api.banking.dto.LoginDetails;
import com.api.banking.dto.LoginResponseDto;
import com.api.banking.dto.RegisterAccountRequestDto;
import com.api.banking.dto.UserLoginResponseDto;
import com.api.banking.exception.InavalidAccountException;
import com.api.banking.exception.InvalidUserLoginException;
import com.api.banking.repository.AccountHistoryRepositroy;
import com.api.banking.repository.CustomerRespository;
import com.api.banking.service.BeneficiaryService;
import com.api.banking.service.FundTransferService;
import com.api.banking.service.LoginService;
import com.api.banking.service.UserRegistrationService;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest
public class BankingFundTransferTest {


	@Autowired
	UserRegistrationService userRegistrationService;
	@Autowired
	BeneficiaryController beneficiaryController;
	@Autowired
	UserLoginController loginController;
	@Autowired
	FundTransferController fundTransferController;
	@Autowired
	LoginService loginService;	
	@Autowired
	BeneficiaryService beneficiaryService;	
	@Autowired
	FundTransferService fundTransferService;


	RegisterAccountRequestDto registerAccountRequestDto;
	UserLoginResponseDto expectedUserLoginResponseDto;

	LoginDetails loginDetails;
	LoginResponseDto expectedLoginResponseDto;

	BeneficiaryRequestDto beneficiaryRequestDto;
	BeneficiaryResponseDto expectedBeneficiaryResponseDto; 

	FundTransferRequestDto fundTransferRequestDto;
	FundTransferResponse expectedFundTransferResponse;






	@Test
	@Order(1)
	void TestCase_1_checkSuccesfull_UserRegistration() {

		/*#####################################################################################*/		

		//Arrange
		registerAccountRequestDto=new RegisterAccountRequestDto("Rajni", "Yadav", "F", 35, new Date(1986,11,10), "rajni@gmail.com",  "AIDPY4423R", "123456789432","9956254682", "Lucknow");
		expectedUserLoginResponseDto=new UserLoginResponseDto(true, "Registration Succesful", "Rajni Yadav", "2021000001", null);


		//Act
		UserLoginResponseDto responseDto_1=userRegistrationService.createAccount(registerAccountRequestDto);

		expectedUserLoginResponseDto.setPassword(responseDto_1.getPassword());



		//Assert
		assertEquals(expectedUserLoginResponseDto, responseDto_1);

		/*#####################################################################################*/

		//Arrange
		registerAccountRequestDto=new RegisterAccountRequestDto("Pooja", "Yadav", "F", 30, new Date(1991,4,20), "pooja@gmail.com", "AIDPY2323R", "123456789123","6656254685", "Lucknow");
		expectedUserLoginResponseDto=new UserLoginResponseDto(true, "Registration Succesful", "Pooja Yadav", "2021000002", null);


		//Act
		UserLoginResponseDto responseDto_2=userRegistrationService.createAccount(registerAccountRequestDto);

		expectedUserLoginResponseDto.setPassword(responseDto_2.getPassword());



		//Assert
		assertEquals(expectedUserLoginResponseDto, responseDto_2);

		/*#####################################################################################*/

		//Arrange
		registerAccountRequestDto=new RegisterAccountRequestDto("Bhanu", "Yadav", "M", 40, new Date(1981,8,15), "bhanu@gmail.com",  "AIDPY2348R", "123456345123","6656258885", "Lucknow");
		expectedUserLoginResponseDto=new UserLoginResponseDto(true, "Registration Succesful", "Bhanu Yadav", "2021000003", null);



		//Act
		UserLoginResponseDto responseDto_3=userRegistrationService.createAccount(registerAccountRequestDto);

		expectedUserLoginResponseDto.setPassword(responseDto_3.getPassword());



		//Assert
		assertEquals(expectedUserLoginResponseDto, responseDto_3);

		/*#####################################################################################*/		




	}



	@Test
	@Order(2)
	void TestCase_2_checkInvalidUserLoginException_UserLogin() {

		//Arrange
		loginDetails=new LoginDetails("2021000001", getCustomerPassword("2021000001"));


		//Act
		Executable executable_0= ()-> { loginService.customerLogin(loginDetails); };

		//Assert
		assertThrows(InvalidUserLoginException.class, executable_0 ,"Account must not be activated");



		//Arrange
		loginDetails=new LoginDetails("2021000002", getCustomerPassword("2021000002"));

		//Act
		Executable executable_1= ()-> { loginService.customerLogin(loginDetails); };

		//Assert
		assertThrows(InvalidUserLoginException.class, executable_1 ,"Account must be blocked for security reasons.");


	}






	/** 
	 * Before Execution This Test Case Must Activated Account
	 * Query Needed<br> 
	 * <b>Update public.customer_details set authorization_status=true where customer_id=?;</b>
	 **/
	@Test
	@Order(3)
	void TestCase_3_checkSuccesfull_UserLogin() {

		this.loginService=mock(LoginService.class);

		//Arrange
		loginDetails=new LoginDetails("2021000001", "rajnakdp88");
		expectedLoginResponseDto=new LoginResponseDto("2021000002", new BigInteger("1107190066"), "SAVING", "Gomti Nagar Lucknow", "SBIIN0001", 10000.00, "Login Succesfull", "Rajni Yadav");

		when(this.loginService.customerLogin(loginDetails)).thenReturn(expectedLoginResponseDto);


		//Act
		LoginResponseDto responseDto=loginService.customerLogin(loginDetails);

		//Assert
		assertEquals(expectedLoginResponseDto, responseDto);


	}

	@Test
	@Order(4)
	void TestCase_4_checkSuccesfull_addBeneficary() {


		beneficiaryRequestDto=new BeneficiaryRequestDto("2021000001", "Uaday", new BigInteger("20102001412"), "BARBO002145", "BOB Alambag,Lucknow", 10000.00);
		expectedBeneficiaryResponseDto=new BeneficiaryResponseDto("Uaday", "Beneficiary Added Succesfully...!!!");

		assertEquals(expectedBeneficiaryResponseDto, beneficiaryService.createBeneficiaryAccount(beneficiaryRequestDto));		


	}


	@Test
	@Order(5)
	void TestCase_5_checkFor_InavalidAccountException_WhenAddBeneficary() {

		//Arrange
		beneficiaryRequestDto=new BeneficiaryRequestDto("2021000001", "Uaday", new BigInteger("20102001412"), "SBIIN0001", "Gomti Nagar Lucknow", 10000.00);

		//Act
		Executable executable=()->{beneficiaryService.createBeneficiaryAccount(beneficiaryRequestDto);};

		//Assert
		assertThrows(InavalidAccountException.class, executable,"Beneficiary account nunber already exist..!!!!!!");		


	}






	/*

	@Test
	void TestCase_6_checkFor_beneficiaryAccountNumberNotFound_whenFundTransaction() {


		fundTransferRequestDto=new FundTransferRequestDto("2021000002", new BigInteger("20102001254"), "BARBO002145", 500.00);
		expectedFundTransferResponse=new FundTransferResponse(true, "Rs.500.0 successfully transferred to account 20102001254. Transaction Id :2", new BigInteger("1107358454"), new BigInteger("20102001254"));

		Executable executable=()->{fundTransferService.fundTransfer(fundTransferRequestDto);};

		assertThrows(ToAccountNumberNotFoundException.class,executable,"Can only transfer to Beneficiary accounts registed with Customer." );

	}

	 */	

	@Test
	@Order(6)
	void TestCase_6_checkFor_beneficiaryAccountNumberNotFound_whenFundTransaction() {


		fundTransferRequestDto=new FundTransferRequestDto("2021000001", new BigInteger("20102001912"), "BARBO002145", 500.00);
		expectedFundTransferResponse=new FundTransferResponse(true, "Rs.500.0 successfully transferred to account 20102001912. Transaction Id :2", new BigInteger("1107358454"), new BigInteger("20102001254"));

		Executable executable=()->{fundTransferService.fundTransfer(fundTransferRequestDto);};

		assertThrows(RuntimeException.class,executable,"Can only transfer to Beneficiary accounts registed with Customer." );

	}


	@Test
	@Order(7)
	void TestCase_7_checkSuccesfull_fundTransaction() {

		//Arrange
		this.fundTransferService=mock(FundTransferService.class);

		fundTransferRequestDto=new FundTransferRequestDto("2021000001", new BigInteger("20102001412"), "SBIIN0001", 500.00);
		expectedFundTransferResponse=new FundTransferResponse(true, "Rs.500.0 successfully transferred to account 20102001412. Transaction Id :2", new BigInteger("1107190066"), new BigInteger("20102001412"));


		when(this.fundTransferService.fundTransfer(fundTransferRequestDto)).thenReturn(expectedFundTransferResponse);

		//Act
		FundTransferResponse responseDto=fundTransferService.fundTransfer(fundTransferRequestDto);

		assertEquals(expectedFundTransferResponse, responseDto,"Successfull Fund Transfer.");

	}


	@Autowired
	CustomerRespository customerRespository;

	@Autowired
	AccountHistoryRepositroy accountHistoryRepositroy;	

	private String getCustomerPassword(String customer_id) {

		return customerRespository.findPasswordByCustomerId(customer_id).getPassword();

	}

	@Test
	@DisplayName("Login Controller: Positive Scenario")
	@Order(8)
	public void loginControllerTest() {
		//Arrange
		this.loginController=mock(UserLoginController.class);

		//Arrange
		loginDetails=new LoginDetails("2021000001", "rajnakdp88");
		expectedLoginResponseDto=new LoginResponseDto("2021000002", new BigInteger("1107190066"), "SAVING", "Gomti Nagar Lucknow", "SBIIN0001", 10000.00, "Login Succesfull", "Rajni Yadav");


		//context
		when(loginController.userLogin(loginDetails)).thenReturn(new ResponseEntity<>(expectedLoginResponseDto, HttpStatus.OK));

		//event
		ResponseEntity<LoginResponseDto> result = loginController.userLogin(loginDetails);

		//outcome
		assertEquals(expectedLoginResponseDto, result.getBody());
	}
	
	@Test
	@DisplayName("Beneficiary Controller : Positive Scenario")
	@Order(9)
	public void BeneficiaryControllerTest() {
		
		this.beneficiaryController=mock(BeneficiaryController.class);
		
		beneficiaryRequestDto=new BeneficiaryRequestDto("2021000001", "Uaday", new BigInteger("20102001412"), "BARBO002145", "BOB Alambag,Lucknow", 10000.00);
		expectedBeneficiaryResponseDto=new BeneficiaryResponseDto("Uaday", "Beneficiary Added Succesfully...!!!");
		
		//context
		when(beneficiaryController.createBeneficiaryAccount(beneficiaryRequestDto)).thenReturn(new ResponseEntity<>(expectedBeneficiaryResponseDto, HttpStatus.OK));

		//event
		ResponseEntity<BeneficiaryResponseDto> result = beneficiaryController.createBeneficiaryAccount(beneficiaryRequestDto);

		//outcome
		assertEquals(expectedBeneficiaryResponseDto, result.getBody());

	}
	
	@Test
	@DisplayName("FundTansfer Controller : Positive Scenario")
	@Order(10)
	public void FundTansferControllerTest() {
		
		this.fundTransferController=mock(FundTransferController.class);
		
		fundTransferRequestDto=new FundTransferRequestDto("2021000001", new BigInteger("20102001412"), "BARBO002145", 500.00);
		expectedFundTransferResponse=new FundTransferResponse(true, "Rs.500.0 successfully transferred to account 20102001412. Transaction Id :3", new BigInteger("1107358454"), new BigInteger("20102001412"));
		
		//context
		when(fundTransferController.fundTransfer(fundTransferRequestDto)).thenReturn(new ResponseEntity<>(expectedFundTransferResponse, HttpStatus.OK));

		//event
		ResponseEntity<FundTransferResponse> result = fundTransferController.fundTransfer(fundTransferRequestDto);

		//outcome
		assertEquals(expectedFundTransferResponse, result.getBody());

	}


}
