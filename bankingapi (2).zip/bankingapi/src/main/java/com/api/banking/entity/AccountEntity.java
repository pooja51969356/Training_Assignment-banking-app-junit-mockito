package  com.api.banking.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;

import lombok.Data;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity(name = "account_details")
public class AccountEntity {
	
	@Id
	@Column(name = "account_number")
	private BigInteger  accountNumber;
	@Column(name = "account_type")
	private String accountType;
	@Column(name = "branch_address")
	private String branchAddress;
	@Column(name = "branch_code")
	private String branchCode;
	@Column(name = "ifsc_code")
	private String ifscCode;
	@Column(name = "opening_balance")
	private Double openingBalance;
	
	@OneToOne(fetch = FetchType.LAZY ,cascade = CascadeType.ALL)
	@JoinColumn(name = "customer_id")
	private CustomerEntity customer;
	

}


