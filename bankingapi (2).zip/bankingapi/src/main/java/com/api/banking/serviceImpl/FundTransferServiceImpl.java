package  com.api.banking.serviceImpl;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.Date;
import java.util.Optional;

import javax.lang.model.type.UnknownTypeException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import  com.api.banking.dto.FundTransferRequestDto;
import  com.api.banking.dto.FundTransferResponse;
import  com.api.banking.entity.AccountEntity;
import  com.api.banking.entity.BeneficiaryEntity;
import  com.api.banking.entity.CustomerEntity;
import  com.api.banking.entity.TransactionEntity;
import  com.api.banking.exception.InavalidAccountException;
import  com.api.banking.exception.InsufficientBalanceException;
import  com.api.banking.exception.ToAccountNumberNotFoundException;
import  com.api.banking.repository.AccountHistoryRepositroy;
import  com.api.banking.repository.BeneficiaryRepository;
import  com.api.banking.repository.CustomerRespository;
import  com.api.banking.repository.FundTransferRepository;
import  com.api.banking.service.FundTransferService;

import io.swagger.models.auth.In;


@Service
public class FundTransferServiceImpl implements FundTransferService{
	private static final Logger logger = LoggerFactory.getLogger(FundTransferServiceImpl.class);

	@Autowired
	private FundTransferRepository fdao;
	@Autowired
	private AccountHistoryRepositroy ahdao;
	@Autowired
	private BeneficiaryRepository bdao;
	@Autowired
	private CustomerRespository cdao;
	
	
	@Override
	public FundTransferResponse fundTransfer(FundTransferRequestDto fundTransferRequestDto) {

		try {

			Optional<BeneficiaryEntity> beneficiaryEntityDetail =getBeneficiaryDetailByAccountNumberAndCustomerId(fundTransferRequestDto.getBeneficiaryAccountNo(),fundTransferRequestDto.getCustomerId());

			

			logger.info("beneficiary Account No in DB"+fundTransferRequestDto.getBeneficiaryAccountNo());
			//check beneficiary account no exist
			if(beneficiaryEntityDetail.isEmpty() || beneficiaryEntityDetail.get().getAccountNo().compareTo(fundTransferRequestDto.getBeneficiaryAccountNo())!=0 ) {
				String msg="AccountNo "+fundTransferRequestDto.getBeneficiaryAccountNo()+" not found in Beneficiary. You can only transfer to Beneficiary accounts registed with you.";
				logger.info(msg);
				throw new ToAccountNumberNotFoundException(msg);
			}
						
			if( beneficiaryEntityDetail.get().getMaxTransactionAmountLimit() <fundTransferRequestDto.getAmount()) {
				
				String msg="Beneficiary Transaction Limit is less than transaction amount";
				logger.info(msg);
				throw new InsufficientBalanceException(msg);
			}
			CustomerEntity customerEntityDetail=getByCustomerId(fundTransferRequestDto.getCustomerId());
			//check minimum account for transfer
			if(customerEntityDetail.getAccountDetail().getOpeningBalance() <fundTransferRequestDto.getAmount()) {
				
				String msg="Insufficient funds to complete the transaction";
				logger.info(msg);
				throw new InsufficientBalanceException(msg);
			}
			
			
			BigInteger fromAccount=customerEntityDetail.getAccountDetail().getAccountNumber();
			
			return transfer( fromAccount, fundTransferRequestDto.getBeneficiaryAccountNo(),   fundTransferRequestDto.getAmount());
			
			
			

		} catch (Exception e) {
			
			logger.info("Transaction Fail");
			throw new RuntimeException("Transaction Fail..!!! "+e.getLocalizedMessage());
			
		}


	}
	
	
	private FundTransferResponse transfer(BigInteger fromAccount,BigInteger toAccount,  Double amount) {
		
		FundTransferResponse response=new FundTransferResponse();
		boolean flag=true;
		
		try {
			
			logger.info("enter in block");
			
			
			AccountEntity senderAccount=ahdao.findByAccountNumber(fromAccount);
			senderAccount.setOpeningBalance(senderAccount.getOpeningBalance()-amount);
			
			
			Optional<BeneficiaryEntity> receiverAccount=bdao.findByAccountNo(toAccount);
			
			if(receiverAccount.get().getBalance()!=null)
				receiverAccount.get().setBalance( (receiverAccount.get().getBalance()+amount));
			else
				receiverAccount.get().setBalance( (amount));
			
			
			
			TransactionEntity transactionEntity =fdao.save(prepareTransaction(fromAccount, toAccount, amount));	//transfer fund
			AccountEntity accountEntity =ahdao.save(senderAccount);					//update customer opening balance	
			BeneficiaryEntity beneficiaryEntity =bdao.save(receiverAccount.get());  	//update beneficiary balance
			
			logger.info("save data");
			
			
			if(transactionEntity !=null && accountEntity!=null && beneficiaryEntity!=null) {
		//	if(transactionEntity !=null && accountEntity!=null) {	
				response.setResponseMessage("Rs."+amount+" successfully transferred to account "+toAccount+". Transaction Id :"+transactionEntity.getTransactionId());
				response.setTransferStatus(flag);
				
			}else {
				
				response.setResponseMessage("Rs."+amount+"  not transferred to account "+toAccount);
				response.setTransferStatus(flag);
				
			}
				



		}catch (Exception e) {
			
			logger.error("Invalid Transaction");
			throw new InavalidAccountException("Transaction Fail....!!!");
		}
		
		
		response.setFromAccount(fromAccount);
		response.setToAccount(toAccount);
		
		
		return response;
	}

	
	
	
	public TransactionEntity prepareTransaction(BigInteger fromAccount, BigInteger toAccount, Double amount) {
		
		java.util.Date date=new java.util.Date();
		
		TransactionEntity transfer=new TransactionEntity();
		transfer.setToAccount(toAccount);
		transfer.setFromAccount(fromAccount);
		transfer.setAmount(amount);
		transfer.setTransactionTime(date);
		
		return transfer;
	}

	

	@Override
	public Optional<BeneficiaryEntity> getBeneficiaryDetailByAccountNumber(BigInteger accountNumber) {
		// TODO Auto-generated method stub
		return bdao.findByAccountNo(accountNumber);
	}



	@Override
	public CustomerEntity getByCustomerId(String customerId) {
		// TODO Auto-generated method stub
		return cdao.findByCustomerId(customerId);
	}


	@Override
	public Optional<BeneficiaryEntity> getBeneficiaryDetailByAccountNumberAndCustomerId(BigInteger accountNumber,
			String customerId) {
		// TODO Auto-generated method stub
		return bdao.findByAccountNoAndCustomerId(accountNumber,customerId);
	}

	
	
}
