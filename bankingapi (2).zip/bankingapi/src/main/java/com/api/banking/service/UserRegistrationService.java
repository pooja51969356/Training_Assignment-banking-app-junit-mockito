package  com.api.banking.service;

import java.util.List;

import com.api.banking.dto.RegisterAccountRequestDto;
import com.api.banking.dto.UserLoginResponseDto;




public interface UserRegistrationService {
	public UserLoginResponseDto createAccount(RegisterAccountRequestDto registerAccountRequestDto);

	
}
