package com.api.banking.entity;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Objects;

import javax.persistence.Column;

public class BeneficiaryIdEntity implements Serializable {
	@Column(name="account_no")
	private BigInteger accountNo ;

	@Column(name = "customer_id")
    private String customerId;

	   

	    public BeneficiaryIdEntity() {
		super();
		
	    	}

		public BeneficiaryIdEntity(BigInteger accountNo, String customerId) {
	        this.accountNo = accountNo;
	        this.customerId = customerId;
	    }

		@Override
		public int hashCode() {
			return Objects.hash(accountNo, customerId);
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			BeneficiaryIdEntity other = (BeneficiaryIdEntity) obj;
			return Objects.equals(accountNo, other.accountNo) && Objects.equals(customerId, other.customerId);
		}

	    
	}
