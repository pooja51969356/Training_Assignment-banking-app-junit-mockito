package   com.api.banking.dto;

public interface PasswordOnly {
	
	String getPassword();

}
