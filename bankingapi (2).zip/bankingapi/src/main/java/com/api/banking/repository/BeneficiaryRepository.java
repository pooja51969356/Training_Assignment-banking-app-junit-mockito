package  com.api.banking.repository;

import java.math.BigInteger;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.api.banking.entity.BeneficiaryEntity;



public interface BeneficiaryRepository extends JpaRepository<BeneficiaryEntity, BigInteger> {

	
	Optional<BeneficiaryEntity> findByAccountNo(BigInteger accountNo);

	Optional<BeneficiaryEntity> findByAccountNoAndCustomerId(BigInteger beneficiaryAccountNo, String customerId);

}
