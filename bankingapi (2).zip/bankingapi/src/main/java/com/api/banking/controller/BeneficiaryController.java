package com.api.banking.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import  com.api.banking.dto.BeneficiaryRequestDto;
import  com.api.banking.dto.BeneficiaryResponseDto;
import  com.api.banking.serviceImpl.BeneficiaryServiceImpl;

@RestController
@Validated
public class BeneficiaryController {
@Autowired
BeneficiaryServiceImpl service;


@RequestMapping(path = "api/user/beneficiary/addBeneficiary",method = RequestMethod.POST)
public ResponseEntity<BeneficiaryResponseDto>createBeneficiaryAccount(@Valid @RequestBody BeneficiaryRequestDto benificiaryRequestDto) {
	
	return ResponseEntity.ok(service.createBeneficiaryAccount(benificiaryRequestDto));

}
}
