package  com.api.banking.dto;

import java.math.BigInteger;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.NumberFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class FundTransferRequestDto {
	
	 @NotNull(message="provide customerId")
	 private  String customerId;
//	 @Size(min = 5, max = 13)
	// @NotNull(message="provide to account no ,only digits")
//	 @Pattern(regexp = "[0-9]{13}",message = "provide a valid to account no") 
	// @NumberFormat(pattern="provide to account no ,only digits")
	@Digits(fraction = 0, integer = 13 ,message = "Provide Beneficiary Account No")
	@DecimalMin(value = "0.0",inclusive = false)
	 private  BigInteger beneficiaryAccountNo;
	 @NotNull(message = "provide valid ifs Code.")
	 @Pattern(regexp = "[a-zA-Z0-9]+",message = "provide valid ifs Code")
	 private  String beneficiaryIfsCode;
	 @NotNull(message="provide transfer amount")
//	 @NumberFormat
//	 @Pattern(regexp = "[0-9.#]+",message = "provide valid Transfer amount")
	 @Digits(fraction = 0, integer = 13 ,message = "Provide Transaction Amount")
	 @DecimalMin(value = "0.0",inclusive = false,message = "Provide Transaction Amount")
	private  Double  amount;

}
