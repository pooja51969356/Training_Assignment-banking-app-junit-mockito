package com.api.banking.controller;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import  com.api.banking.dto.FundTransferRequestDto;
import  com.api.banking.dto.FundTransferResponse;
import  com.api.banking.service.FundTransferService;


@RestController
@Validated
public class FundTransferController {
	
	
	
		
	
	
	@Autowired
	FundTransferService fundTransferService;

	
//	@PostMapping("api/user/account/fundtransfer")
	@RequestMapping(path = "api/user/fundtransfer",method = RequestMethod.POST)
	public ResponseEntity<FundTransferResponse> fundTransfer(@Valid @RequestBody FundTransferRequestDto fundTransferRequestDto) {
			
			return ResponseEntity.ok(fundTransferService.fundTransfer(fundTransferRequestDto));

	}	

}
