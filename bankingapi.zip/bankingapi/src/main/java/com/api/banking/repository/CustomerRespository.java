package  com.api.banking.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.api.banking.dto.PasswordOnly;
import com.api.banking.entity.CustomerEntity;



public interface CustomerRespository extends JpaRepository<CustomerEntity, String> {

	Optional<CustomerEntity> findByPanNumber(String panNumber);

	Optional<CustomerEntity> findByAdhaarNumber(String l);

	Optional<CustomerEntity> findByEmail(String email);

	CustomerEntity findByCustomerId(String customerId);

	CustomerEntity findByFirstName(String username);
	
	PasswordOnly findPasswordByCustomerId(String customerId);
	@Query("SELECT MAX(	(CASE WHEN (SUBSTRING (customer_id,6,11) is null ) THEN '0' ELSE (SUBSTRING (customer_id,6,11) ) END)) as customer_id \r\n"
			+ "			 FROM customer_details 	WHERE SUBSTRING (customer_id,0,5)=:year")
	List<Integer> FindMaxCustomerId(@Param(value = "year") String year);
	
	

}
