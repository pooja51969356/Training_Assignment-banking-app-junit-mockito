package com.api.banking.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.api.banking.entity.CustomerEntity;
import com.api.banking.repository.CustomerRespository;
import com.api.banking.service.UserRegistrationValidationService;

@Service
public class UserRegistrationValidationServiceImpl implements UserRegistrationValidationService {
	
	@Autowired
	CustomerRespository customerRespository;


	@Override
	public boolean panAlreadyExists(String panno) {
		
			Optional<CustomerEntity>  u=customerRespository.findByPanNumber(panno);
			if(u.isEmpty()) {
				return false;
			}else {

				return true;
			}
		
		
	}

	@Override
	public boolean emailAlreadyExists(String email) {
		
			Optional<CustomerEntity> u=customerRespository.findByEmail(email);
			if(u.isEmpty()) {
				return false;
			}else {

				return true;
			}
		
	
	}

	@Override
	public boolean adhaarNumberAlreadyExists(String adhaarNumber) {
	
			Optional<CustomerEntity>  u=customerRespository.findByAdhaarNumber(adhaarNumber);
			if(u.isEmpty()) {
				return false;
			}else {

				return true;
			}

	}

}
