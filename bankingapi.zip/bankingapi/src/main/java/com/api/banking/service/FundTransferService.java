package  com.api.banking.service;

import java.math.BigInteger;
import java.util.Optional;

import com.api.banking.dto.FundTransferRequestDto;
import com.api.banking.dto.FundTransferResponse;
import com.api.banking.entity.BeneficiaryEntity;
import com.api.banking.entity.CustomerEntity;



public interface FundTransferService {
	
	
	public FundTransferResponse fundTransfer(FundTransferRequestDto fundTransferRequestDto);
	public Optional<BeneficiaryEntity> getBeneficiaryDetailByAccountNumber(BigInteger accountNumber);
	public Optional<BeneficiaryEntity> getBeneficiaryDetailByAccountNumberAndCustomerId(BigInteger accountNumber,String customerId);
	public CustomerEntity getCustomerByCustomerId(String customerId);
}
