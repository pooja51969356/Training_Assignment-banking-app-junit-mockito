package  com.api.banking.dto;

import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class LoginDetails {
	@NotEmpty(message = "provide customer Id.")
	private String customerId;
	@NotEmpty(message = "provide password.")
	private String password;
	
	
}
