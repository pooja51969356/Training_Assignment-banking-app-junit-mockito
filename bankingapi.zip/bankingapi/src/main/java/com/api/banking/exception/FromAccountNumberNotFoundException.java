package  com.api.banking.exception;

public class FromAccountNumberNotFoundException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public FromAccountNumberNotFoundException(String message) {
		super(message);

	}

	public FromAccountNumberNotFoundException(String message, Throwable t) {
		super(message, t);

	}
}
