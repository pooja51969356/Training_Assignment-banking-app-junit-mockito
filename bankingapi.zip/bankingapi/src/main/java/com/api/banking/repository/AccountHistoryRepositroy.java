package  com.api.banking.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.api.banking.entity.AccountEntity;



public interface AccountHistoryRepositroy extends JpaRepository<AccountEntity, String>{


	public AccountEntity findByAccountNumber(BigInteger fromAccount);
	
	
//	public BigInteger findAccountNumberByCustomerId(String customer_id);
	
	
}
