package com.api.banking.service;

public interface UserRegistrationValidationService {
	
	public boolean panAlreadyExists(String panno);
	public boolean emailAlreadyExists(String email);
	public boolean adhaarNumberAlreadyExists(String l);

}
