package  com.api.banking.service;

import  com.api.banking.dto.BeneficiaryRequestDto;
import  com.api.banking.dto.BeneficiaryResponseDto;

public interface BeneficiaryService {

	public BeneficiaryResponseDto createBeneficiaryAccount(BeneficiaryRequestDto benificiaryDto);
}
