package  com.api.banking.dto;

import java.util.Date;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class RegisterAccountRequestDto {
	@NotEmpty(message = "provide first name.")
	private String firstName;
	@NotEmpty(message = "provide last name. ")
	private String lastName;
	@NotEmpty(message = "provide gender.")
	private String gender;
	private int age;
	private Date dob;
	@NotEmpty(message = "Provide email id.")
	@Email
	private String email;
	@NotEmpty(message = "provide pan number")
	@Pattern(regexp = "[A-Z]{5}[0-9]{4}[A-Z]{1}", message = "provide valid pan number.")
	private String panNumber;
	@NotNull(message = "provide mobile no ,only digits.")
	@Pattern(regexp = "[0-9]{10}", message = "provide valid mobile no")
	private String phoneNumber;
	@NotNull(message = "provide aadhaar number,only digits. ")
	@Pattern(regexp = "[0-9]{12}", message = "provide valid aadhaar number.")
	private String adhaarNumber;
	@NotEmpty(message = "Provide Customer Address.")
	private String address;
}
